# RedNote Video Script Generator & Optimizer

## Skill Description
Generate and optimize engaging 小红书 (RedNote) video scripts in Chinese, matching the user's established writing style while incorporating current trends and accurate product information.

## Invocation Modes

| Command | Mode | Description |
|---------|------|-------------|
| `/rednote` | Create | 创建新脚本 (default) |
| `/rednote optimize` | Optimize | 优化已有脚本 |

---

# MODE 1: CREATE (Default)

## When to Use
User invokes `/rednote` or `/rednote create` to draft a new video script.

## Style Reference
**IMPORTANT:** Before generating any script, you MUST:
1. Read `resources/writing-style-guide.md` for the user's signature style patterns
2. Search Notion for similar past scripts to match tone and structure
3. Apply the persona: 北美全职码农小经理 + 副业博主

## Notion Integration
The user's past video scripts are stored in Notion under the "Videos Schedule" database.

### Finding Reference Scripts
Use `mcp__notion__notion-search` with queries like:
- Product category: "护肤 精华" or "面霜 测评"
- Content type: "种草" "开箱" "攻略" "vlog"
- Similar themes to the requested topic

### Fetching Script Details
Use `mcp__notion__notion-fetch` with the page ID to get full script content for style reference.

## Create Workflow

### Step 1: Gather Information
Ask the user for:
1. **产品/主题** (Product or topic) - What is the video about?
2. **视频时长** (Video length) - How long? (30秒, 1分钟, 3分钟, 5-10分钟)
3. **内容类型** (Content type) - 种草/测评/开箱/攻略/vlog/合作

### Step 2: Research & Reference
1. Read `resources/writing-style-guide.md`
2. Search Notion for 2-3 similar past scripts
3. Fetch and analyze their structure, tone, and phrases

### Step 3: Generate Script
Apply the user's style characteristics:

**Opening (开场):**
- Use personal hook: "作为一个北美全职码农小经理..."
- Or emotional opening: "宝子们！" "谁能懂啊！"
- Set scene/context relevant to the topic

**Product Descriptions (每个产品至少30-45秒口播):**

每个产品必须包含以下**7个要素**，确保内容丰富有深度：

1. **品牌故事/产品背景** (5-10秒)
   - 品牌来源地、创立故事
   - 为什么这个产品特别/值得关注
   - 例：「这是法国贵妇牌Biologique Recherche的王牌产品，人家做护肤已经40多年了...」

2. **外观/包装描述** (3-5秒)
   - 包装设计、颜色、质感
   - 便携性、用量控制
   - 例：「瓶子是那种低调的磨砂玻璃，按压头出量很好控制...」

3. **质地/肤感详述** (5-8秒)
   - 具体触感比喻（像什么质地）
   - 推开时的感觉
   - 吸收速度
   - 例：「质地是淡奶油状的，但是推开就化成水，一秒吸收，完全不黏腻...」

4. **核心成分深度解读** (8-12秒)
   - 2-3个核心成分名称
   - 每个成分的功效（用通俗语言）
   - 成分浓度/配比亮点（如有）
   - 例：「主打成分是10%的烟酰胺，搭配传明酸，一个提亮一个祛斑，双管齐下...」

5. **使用方法/场景** (5-8秒)
   - 推荐使用时间（早晚/周几次）
   - 用量建议
   - 搭配建议
   - 例：「我喜欢晚上用，取3-4滴，在精华之前用，也可以混在面霜里...」

6. **个人真实体验** (8-12秒)
   - 使用周期（用了多久）
   - 具体效果（肉眼可见的变化）
   - 最打动你的点
   - 例：「用了大概三周，最明显的是泪沟那里居然饱满了一点点！嘴角的细纹也淡了...」

7. **肤质适配建议 + 优缺点** (5-8秒)
   - 哪些人群适合/不适合
   - 客观缺点（增加可信度）
   - 性价比评价
   - 例：「干皮闭眼冲，油皮夏天可能会觉得有点润。唯一缺点就是价格不太美丽...」

**产品介绍结构示例:**
```
【产品名】XX品牌XX产品

这是[品牌背景1-2句]。包装是[外观描述]。

质地呢是[详细质地描述]，上脸[肤感描述]。

核心成分是[成分1]，主打[功效]；还有[成分2]，可以[功效]。配方[亮点]。

我一般[使用方法]，配合[搭配产品]效果更好。

真的用下来[使用周期]，[具体效果]，最惊喜的是[最打动的点]。

[肤质]的姐妹可以[建议]。[诚实说一个小缺点]。

总的来说，[一句话总结]。
```

**Language Style:**
- Use signature phrases: 直接拉满, 闭眼冲, yyds, 在线, 妥妥的
- Conversational tone (口语化)
- Strategic emoji placement (✨😭🤯)
- Mix Chinese with English product names naturally

**Closing (结尾):**
- 总结升华 - connect to lifestyle, not just products
- 互动引导 - "评论区告诉我～" "喜欢点赞收藏"

### Step 4: Output Format
输出为**一体化脚本**，分镜头紧跟每个内容段落后面，不单独分开。

**重要：文档最上方必须包含纯口播脚本（方便读稿）**

```markdown
## 📖 纯口播脚本（读稿用）

---

**【开场】**
[开场口播内容，连续段落，无分镜]

**【产品1：XX】**
[产品1完整口播，连续段落，无分镜]

**【产品2：XX】**
[产品2完整口播，连续段落，无分镜]

...

**【结尾】**
[结尾口播内容，连续段落，无分镜]

---
---

## 标题选项
1. [emoji][标题1]
2. [emoji][标题2]
3. [emoji][标题3]

---

## 完整脚本 + 分镜

### 【开场】0:00-0:XX
**口播**:
[完整口播内容]

**分镜**:
| 镜号 | 时间 | 景别 | 画面 | 运镜 | 字幕 |
|------|------|------|------|------|------|
| 1 | 0:00-0:03 | 近景 | 具体画面 | 固定 | 字幕内容 |

---

### 【产品1：XX】0:XX-0:XX
**口播**:
[详细产品介绍，按7要素展开]

**分镜**:
| 镜号 | 时间 | 景别 | 画面 | 运镜 | 字幕 |
|------|------|------|------|------|------|
| 2 | 时间 | 特写 | 产品外观 | 缓推 | 品牌名 |
| 3 | 时间 | 特写 | 质地展示 | 俯拍 | 「质地超绝」 |
| ... | ... | ... | ... | ... | ... |

---

### 【产品2：XX】...
[同样格式]

---

### 【结尾】最后XX秒
**口播**:
[总结+互动引导]

**分镜**:
| 镜号 | 时间 | 景别 | 画面 | 运镜 | 字幕 |
|------|------|------|------|------|------|

---

## 拍摄准备清单
[道具、场景、后期提示]

## 推荐标签
#标签1 #标签2 ...

---

## 🎨 封面设计建议
[根据脚本内容自动生成，参考 cover-design.md skill]
```

### Step 5: Cover Design Suggestion
脚本生成完成后，**自动**提供封面设计建议（参考 `.claude/skills/cover-design.md`）：

1. 根据视频主题和产品数量选择封面类型
2. 从脚本标题提取3个封面标题选项
3. 推荐配色方案
4. 提供美图设计室操作步骤

## Script Templates by Length

### 30秒-1分钟
```
【开场】(0:00-0:05)
- 1句话人设切入 + 痛点

【主体】(0:05-0:25)
- 产品核心亮点
- 质地+效果

【收尾】(0:25-0:30)
- 简短推荐语
```

### 3分钟
```
【开场】(0:00-0:15)
- 场景/情绪引入
- 主题预告

【产品介绍】(0:15-2:30)
- 品牌背景
- 质地描述
- 成分功效
- 使用方法
- 个人体验

【结尾】(2:30-3:00)
- 总结
- 互动引导
```

### 3-5分钟 (2-3个产品深度种草)
```
【开场】(0:00-0:30)
- 氛围营造
- 内容概览

【产品分段】(每个产品60-90秒)
- 按7要素完整展开
- 每个产品都要有深度
- 过渡自然

【结尾】(最后20-30秒)
- 快速总结
- 互动引导
```

### 5-10分钟 (多产品合集)
```
【开场】(0:00-0:45)
- 氛围营造 + 痛点共鸣
- 产品快闪预告

【产品分段】(每个产品45-60秒)
- 7要素按重要性取舍
- 重点产品可延长到90秒
- 产品间用口播过渡

【结尾】(最后30-60秒)
- 总结升华
- 互动引导
```

**时间分配参考 (以6个产品/3分钟为例):**
- 开场: 15秒
- 每个产品: 约25秒 (重点产品30-35秒)
- 结尾: 15秒
- 总计: 约180秒

---

# MODE 2: OPTIMIZE

## When to Use
User invokes `/rednote optimize` to improve an existing script with:
- 当前小红书流行叙事风格
- 产品信息核查与更正
- 热门话题和标签更新

## Optimize Workflow

### Step 1: Get the Script
Ask user how they want to provide the script:

**Option A: From Notion**
1. Ask for script name/topic to search
2. Use `mcp__notion__notion-search` to find matching scripts
3. Present options and let user choose
4. Use `mcp__notion__notion-fetch` to get full content
5. Store the page ID for later update

**Option B: Direct Paste**
1. User pastes script content directly
2. Proceed to analysis

### Step 2: Trend Research
Use `WebSearch` to research current RedNote trends:

**Search queries to run:**
```
小红书 2026 爆款文案 叙事风格
小红书 最新 流行语 热梗
小红书 [产品类别] 热门话题
小红书 算法 推荐 技巧 2026
```

**Analyze and extract:**
- 当前流行的开场方式 (hook styles)
- 热门叙事结构 (narrative patterns)
- 新兴流行语和表达 (trending phrases)
- 热门标签和话题 (trending hashtags)

### Step 3: Product Fact-Check
For each product mentioned in the script, use `WebSearch` to verify:

**Search queries:**
```
[产品名] 成分 功效 官网
[产品名] 使用方法 正确用法
[产品名] 真实测评 口碑
[品牌名] 官方 产品介绍
```

**Verify and correct:**
- 产品成分 (ingredients) - 确保准确
- 功效说明 (benefits) - 对照官方说明
- 使用方法 (usage) - 核实正确步骤
- 价格/规格 (specs) - 更新最新信息
- 品牌背景 (brand story) - 事实核查

### Step 4: Generate Optimized Script
Create improved version that:

1. **保留用户风格** - Keep the user's personal voice and persona
2. **融入趋势元素** - Integrate trending hooks, phrases, transitions
3. **更正产品信息** - Fix any inaccurate product details
4. **优化标签** - Update hashtags with trending ones
5. **增强互动** - Improve engagement hooks based on current best practices

### Step 5: Present Changes
Output format:

```markdown
## 优化报告

### 🔥 趋势更新
- [列出融入的流行元素]

### ✅ 产品信息更正
| 产品 | 原内容 | 更正后 | 来源 |
|------|--------|--------|------|
| ... | ... | ... | ... |

---

## 📖 纯口播脚本（读稿用）

**【开场】**
[开场口播内容]

**【产品1：XX】**
[产品1完整口播]

...

**【结尾】**
[结尾口播内容]

---
---

## 📝 优化后脚本 + 分镜

### 【开场】0:00-0:XX
**口播**:
[口播内容]

**分镜**:
| 镜号 | 时间 | 景别 | 画面 | 运镜 | 字幕 |
|------|------|------|------|------|------|

---

### 【产品1：XX】0:XX-0:XX
**口播**:
[详细产品介绍 - 按7要素展开，每个产品30-45秒]

**分镜**:
| 镜号 | 时间 | 景别 | 画面 | 运镜 | 字幕 |
|------|------|------|------|------|------|

---
[继续每个产品...]

---

### 【结尾】
**口播**:
[总结+互动]

**分镜**:
| 镜号 | 时间 | 景别 | 画面 | 运镜 | 字幕 |
|------|------|------|------|------|------|

---

## 📋 拍摄准备清单
**道具**: [产品清单]
**场景**: [场景布置要求]
**后期**: [剪辑、字幕、BGM建议]

## #️⃣ 更新标签
#标签1 #标签2 ...

---

## 🎨 封面设计建议
[优化后自动更新封面建议]
```

### Step 6: Cover Design Update
优化完成后，根据新内容**自动更新**封面建议。

### Step 7: Save Decision
Ask user how to save:

**Option A: 覆盖原脚本**
- Use `mcp__notion__notion-update-page` with original page_id
- Command: `replace_content`

**Option B: 创建新版本**
- Use `mcp__notion__notion-create-pages`
- Title format: "[原标题] - 优化版"
- Link to original in content

---

# SHARED: Notion Database Details

- **Data Source ID**: `60ca6609-300e-4d66-8548-b7ad9c9df98d`
- **Database**: Videos Schedule

## Required Properties for New Pages
```json
{
  "Video Title": "[标题]",
  "○": "准备中",
  "SNS": "[\"Redbook\"]",
  "Tags": "[根据内容选择]",
  "Month": "[当前月份]",
  "date:Date:start": "[YYYY-MM-DD]",
  "date:Date:is_datetime": 0,
  "Theme": "[主题]",
  "Sponsor": "[品牌名或留空]"
}
```

## Platform Specs
- 视频最长: 15分钟
- 最佳比例: 9:16竖屏
- 标题限制: 20字
- 正文/描述: 1000字

---

# STORYBOARD 分镜头脚本

## 小红书视频风格特点
- **竖屏9:16** - 全程竖屏拍摄
- **快节奏** - 每个镜头2-5秒，保持观众注意力
- **强视觉冲击** - 开场3秒必须抓眼球
- **真人出镜** - 增加信任感和亲切感
- **产品特写** - 突出质地、细节、使用过程
- **字幕必备** - 重点信息用花字/贴纸强调
- **自然转场** - 切换干净利落，避免花哨特效

## 分镜头脚本格式

每个镜头包含以下信息：

| 字段 | 说明 |
|------|------|
| **镜号** | Shot 1, Shot 2... |
| **时间** | 起止时间 (如 0:00-0:03) |
| **景别** | 特写/近景/中景/全景 |
| **画面内容** | 具体拍什么 |
| **运镜** | 固定/推/拉/摇/移/手持跟拍 |
| **人物动作** | 博主做什么 |
| **字幕/贴纸** | 屏幕上显示的文字 |
| **BGM/音效** | 背景音乐或音效提示 |
| **备注** | 拍摄注意事项、道具准备 |

## 小红书常用镜头类型

### 开场Hook镜头 (前3秒)
```
| 镜号 | 时间 | 景别 | 画面内容 | 运镜 | 字幕 |
|------|------|------|----------|------|------|
| 1 | 0:00-0:03 | 近景 | 博主惊讶/兴奋表情直视镜头 | 固定 | 「姐妹们！」大字弹出 |
```

**常用Hook类型：**
- 表情杀：夸张表情 + 直击痛点的开场白
- 产品闪现：快速展示所有产品 + 悬念文案
- 效果对比：Before/After 冲击画面
- 数字冲击：「省了3000块」「7天逆袭」

### 产品展示镜头
```
| 镜号 | 时间 | 景别 | 画面内容 | 运镜 | 字幕 |
|------|------|------|----------|------|------|
| A | - | 特写 | 产品外观/包装 | 固定或缓推 | 品牌名+产品名 |
| B | - | 特写 | 质地展示(挤出/倒出) | 俯拍固定 | 「质地超绝」 |
| C | - | 近景 | 上脸/上手使用过程 | 手持跟拍 | 使用方法要点 |
| D | - | 特写 | 使用后效果 | 固定 | 效果描述 |
```

### 口播镜头
```
| 镜号 | 时间 | 景别 | 画面内容 | 运镜 | 字幕 |
|------|------|------|----------|------|------|
| - | - | 中景 | 博主对镜说话 | 固定 | 关键词高亮 |
| - | - | 近景 | 博主+手持产品 | 固定 | 产品名贴纸 |
```

### 结尾镜头
```
| 镜号 | 时间 | 景别 | 画面内容 | 运镜 | 字幕 |
|------|------|------|----------|------|------|
| END | 最后3s | 中景/全景 | 所有产品摆放+博主 | 固定 | 「点赞收藏」贴纸 |
```

## 分镜模板 - 按视频类型

### 单品种草 (30秒-1分钟)
```
Shot 1: Hook - 表情+痛点 (3s)
Shot 2: 产品全貌特写 (3s)
Shot 3: 口播-品牌/背景 (5s)
Shot 4: 质地特写 (3s)
Shot 5: 使用过程 (5s)
Shot 6: 口播-使用感受 (5s)
Shot 7: 效果展示 (3s)
Shot 8: 结尾-推荐+互动 (3s)
```

### 多品合集 (3-5分钟)
```
Shot 1: Hook - 悬念开场 (3s)
Shot 2: 所有产品快闪 (3s)
Shot 3: 口播-主题介绍 (10s)
---循环每个产品---
Shot A: 产品特写 (2s)
Shot B: 口播-产品介绍 (10-15s)
Shot C: 使用/质地展示 (5s)
Shot D: 效果/感受 (5s)
---循环结束---
Shot END-1: 产品全家福 (3s)
Shot END-2: 口播-总结+互动 (10s)
```

### 教程/攻略类 (2-3分钟)
```
Shot 1: Hook - 效果预告 (3s)
Shot 2: 口播-痛点共鸣 (5s)
Shot 3: 步骤1演示 + 口播 (15-20s)
Shot 4: 步骤2演示 + 口播 (15-20s)
Shot 5: 步骤3演示 + 口播 (15-20s)
Shot 6: 最终效果展示 (5s)
Shot 7: 口播-注意事项 (10s)
Shot 8: 结尾-互动引导 (5s)
```

## 拍摄清单生成

每个分镜脚本应附带：

### 📷 设备清单
- 手机/相机
- 三脚架/手机支架
- 补光灯 (环形灯/柔光箱)
- 收音设备 (领夹麦/手机直录)

### 🎬 场景/道具清单
- 拍摄背景 (干净简洁/化妆台/浴室等)
- 产品 (确保包装完好、干净)
- 辅助道具 (化妆镜、托盘、绿植装饰等)
- 服装/妆容准备

### ✂️ 后期提示
- 剪辑节奏建议
- 字幕样式 (字体、颜色、位置)
- BGM风格建议
- 转场方式

## 分镜脚本示例输出格式

```markdown
## 📹 分镜头脚本

### 拍摄概览
- **总时长**: 2分50秒
- **镜头数**: 约25个
- **场景**: 化妆台前
- **服装**: 休闲居家风

### 详细分镜

| 镜号 | 时间 | 景别 | 画面内容 | 运镜 | 人物动作 | 字幕/贴纸 | 备注 |
|------|------|------|----------|------|----------|-----------|------|
| 1 | 0:00-0:03 | 近景 | 博主面部表情 | 固定 | 惊讶→笑 | 「姐妹们！」 | Hook镜头 |
| 2 | 0:03-0:06 | 全景 | 6件产品快速闪过 | 快切 | - | 产品名飞入 | 配节奏感BGM |
| 3 | 0:06-0:15 | 中景 | 博主+桌上产品 | 固定 | 手划过产品介绍 | 关键词高亮 | 主口播 |
| ... | ... | ... | ... | ... | ... | ... | ... |

### 📋 拍摄准备清单
**道具**:
- [ ] Mount Lai刮痧棒
- [ ] Nurse Jamie美容枕
- [ ] ...

**场景布置**:
- [ ] 化妆台整理干净
- [ ] 补光灯45度角
- [ ] 背景简洁无杂物

**后期提示**:
- BGM: 轻快活泼风格
- 字幕: 黑边白字 + 重点词彩色高亮
- 转场: 直接硬切为主，偶尔用缩放转场
```

---

# USER FEEDBACK & COMMON ISSUES

## ⚠️ 常见问题提醒

### 产品介绍内容短暂
**问题**: 产品介绍太简略，每个产品只有几句话
**解决**: 必须按照7要素结构展开，每个产品至少30-45秒口播内容

### 分镜头与脚本分离
**问题**: 分镜头单独列出，不方便对照
**解决**: 每个脚本段落后面直接跟对应的分镜表格，一体化呈现

### 内容过于模板化
**问题**: 口播内容读起来像模板，缺乏个人特色
**解决**:
- 融入更多个人经历和真实感受
- 使用writing-style-guide.md中的口语表达
- 每个产品都要有具体的使用体验

### 成分解读太专业
**问题**: 成分讲解太学术，观众听不懂
**解决**: 用比喻和生活化语言解释，如「烟酰胺就是美白界的老大哥」

### 纯口播脚本方便读稿
**需求**: 拍摄时需要纯口播版本方便读稿，不需要分镜干扰
**解决**: 文档最上方生成「📖 纯口播脚本（读稿用）」，只包含连续口播内容，无分镜表格

---

# Example Sessions

## Create Mode
```
User: /rednote

Claude: 请告诉我：
1. 📦 产品/主题是什么？
2. ⏱️ 视频时长多久？
3. 🎬 内容类型？

User: 3分钟的护肤油种草

Claude: [Generates script, saves to Notion]
```

## Optimize Mode
```
User: /rednote optimize

Claude: 请选择脚本来源：
1. 📂 从Notion选择已有脚本
2. 📋 直接粘贴脚本内容

User: 从Notion选择，变美小工具那个

Claude: [Fetches script from Notion]
[WebSearch for trends]
[WebSearch for product verification]
[Generates optimized version with change report]

Claude: 优化完成！请选择保存方式：
1. 覆盖原脚本
2. 创建新版本

User: 创建新版本

Claude: [Creates new page in Notion with "-优化版" suffix]
```
