"""
AI Tax — Core Module

Tax data models, calculation engine interface, and validation logic.
"""
