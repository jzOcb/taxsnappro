import reflex as rx

config = rx.Config(
    app_name="aitax",
    title="AI Tax 2024",
    description="AI-powered tax preparation",
)
