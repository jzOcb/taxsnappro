"""
AI Tax — Document Parsers

Parse tax documents (W-2, 1099, etc.) from images/PDFs using OCR + LLM extraction.
"""
