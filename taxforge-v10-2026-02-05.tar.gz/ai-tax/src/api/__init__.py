"""
AI Tax — API Layer

Integration with Column Tax API (Year 1) and future custom API.
"""
