# Chinese Social Media Scripts / 中文社交媒体文案项目

A template-based project for creating engaging social media content in Chinese across multiple platforms.

## 项目结构 / Project Structure

```
chinese-social-scripts/
├── CLAUDE.md              # Claude 项目上下文
├── prompts/               # 提示词模板
│   ├── general.md         # 通用提示词
│   ├── rednote.md         # 小红书专用
│   ├── douyin.md          # 抖音专用
│   ├── weibo.md           # 微博专用
│   └── wechat.md          # 微信公众号专用
├── templates/             # 内容模板
│   ├── product-review.md  # 产品测评
│   ├── lifestyle.md       # 生活方式
│   ├── tutorial.md        # 教程攻略
│   └── story.md           # 个人故事
├── scripts/               # 生成的文案
└── resources/             # 参考资料
    ├── platform-specs.md  # 平台规格说明
    └── style-guide.md     # 写作风格指南
```

## 使用方法 / How to Use

### 1. 选择平台 / Choose Platform
Navigate to `prompts/` and select the platform-specific prompt file.

### 2. 选择模板 / Choose Template
Pick a content template from `templates/` based on your content type.

### 3. 生成内容 / Generate Content
Use the prompts and templates with Claude to generate your content.

### 4. 保存输出 / Save Output
Store generated scripts in the `scripts/` directory.

## 支持的平台 / Supported Platforms

| 平台 | Platform | 特点 |
|------|----------|------|
| 小红书 | RedNote | 种草、生活方式分享 |
| 抖音 | Douyin | 短视频脚本 |
| 微博 | Weibo | 热点讨论、快速传播 |
| 微信公众号 | WeChat | 深度内容、私域流量 |

## 内容工作流 / Content Workflow

1. **确定目标** - Define your content goal
2. **选择平台** - Choose target platform(s)
3. **查阅规格** - Check `resources/platform-specs.md`
4. **使用模板** - Apply appropriate template
5. **生成初稿** - Generate first draft
6. **优化修改** - Refine and edit
7. **发布追踪** - Publish and track performance

## 提示 / Tips

- 不同平台有不同的调性，注意适配
- 善用热门话题和标签
- 保持真实、接地气的语言风格
- 定期更新平台规格信息
